# AMIA Design System

Sistema visual da **AMIA — Academia do Marketing com IA**, submarca de Thaís Maia.

Curso + comunidade prática de marketing com IA. Promessa: você entra executando tarefas com IA e sai desenhando processos de marketing com IA. Não é escola de ferramenta — é repertório, processo e aplicação.

---

## 1. Posicionamento

**Promessa:** você entra executando tarefas com IA. Sai desenhando processos de marketing com IA.

Não é escola de ferramenta e não é "300 prompts mágicos". É formação de repertório, processo e aplicação — pra IA virar parte do jeito que você trabalha.

**Transformação:** de operadora de prompts a arquiteta de processos.
- Antes: "me dá uma legenda", copia prompt do Instagram, pula de ferramenta em ferramenta.
- Depois: monta fluxo de conteúdo/campanha, cria biblioteca própria, escolhe ferramenta pelo problema, tem processo que o time segue.

**A prova (diferencial forte) — sai com ativos, não com certificado:**
- Sistema/fluxo rodando
- Playbook interno de IA
- Horas devolvidas (antes × depois)
- Portfólio de 3–5 fluxos aplicados
- Apresentação "IA no marketing em 90 dias"
- Assistentes configurados

**Aluno:** já usa IA todo dia — não é iniciante, não precisa ser convencido. Mas usa no nível mais raso. O que trava é método.

> "Há um mês atrás eu usava o ChatGPT pra melhorar texto — e achava que estava usando IA." — aluna da AMIA

Medo por baixo: *"se qualquer estagiário com ChatGPT faz um post, o que me torna necessária?"*

**Inimigo:** curso raso de prompt solto + o medo de virar dispensável.

**Arquitetura:** o Hub de IA (Segundo Cérebro) é organização/assistentes no Notion e está **dentro** da AMIA. AMIA é a formação de marketing.

**Estrutura:** híbrida — conteúdo aberto + encontros ao vivo, organizada em turmas. Fase inicial: não prometer prazo nem número de alunos.

---

## 2. Cor

Base branca com faixas alternadas em off-white quente. Coral só onde há ação: CTA, setas, números, destaques. Vermelho escuro reservado para urgência real.

| Nome | Hex | Uso |
|---|---|---|
| Branco | `#FFFFFF` | Fundo padrão |
| Off-white quente | `#FBFAF7` | Faixa alternada |
| Quase-preto | `#0E1420` | Texto e bloco forte |
| **Coral ★** | `#EF5A3C` | Acento & CTA — cor de assinatura |
| Coral hover | `#D94A2E` | Hover de coral |
| Urgência | `#D0301A` | Escassez, oferta — só com prazo real |

**Hierarquia de texto — opacidades sobre `#0E1420`:**
- Título / ênfase: 100%
- Corpo principal: 85%
- Prosa longa: 70%
- Legenda / meta: 60%
- Desativado: 50%

Bordas entre seções: `1px rgba(14,20,32,0.06)` (hairline). Cards ativos ganham borda coral 2px.

**Proibido:** verde (marca-mãe), rosa (Segundo Cérebro), lima, gradiente, sombra em botão.

---

## 3. Tipografia

| Fonte | Uso | Peso/estilo |
|---|---|---|
| **Instrument Serif** | Títulos | Sempre itálico. Leading 1.05, tracking tight |
| **DM Sans** | Corpo, UI | 400 pra prosa (leading 1.75), 500/600 pra UI e listas, 700 pra ênfase |

**Escala:**
- Hero: 72px (Instrument Serif itálico)
- Seção: 60px (Instrument Serif itálico)
- Eyebrow: 13px, uppercase, semibold, tracking 0.14em, cor coral
- Prosa: 18px / line-height 1.75
- Contador: número grande em serif itálico + label micro uppercase

---

## 4. Layout & espaço

- Coluna de leitura: 520–640px, centralizada, padding lateral 24px
- Grid 2 colunas: imagens, método
- Grid 3 colunas: prompts, lotes
- Seção: padding-y 56px (mobile) / 80px (desktop)
- Separador: hairline `rgba(14,20,32,.06)`
- Faixas alternadas: branco → off-white → branco
- Raio: 12px card · pill botão · 10px chip
- Sem animação acima da dobra. Imagens com dimensão explícita.

---

## 5. Componentes

- **Botões:** pill, altura 52–56px, coral sólido, sem sombra. Secundário preto sólido. Contorno com borda 1px.
- **Badges/chips:** pill, uppercase, 11px, bold, tracking 0.08em.
- **Card de preço ativo:** borda coral 2px + `box-shadow: 0 10px 30px -12px rgba(239,90,60,0.35)`.
- **Banner de urgência:** fundo `#D0301A`, contador em Instrument Serif itálico coral.
- **Item de módulo:** número em serif itálico coral + título + duração.
- **Depoimento:** borda esquerda coral 2px, citação em Instrument Serif itálico.

---

## 6. Slides de aula (1920×1080)

Margem 96px, texto nunca abaixo de 28px. Catorze moldes: capa · agenda · passo a passo · respiro (bloco coral) · print/prompt · aplicar hoje · diagnóstico/tabela · antes-depois (split) · erro comum · checklist · framework/fluxo · exercício ao vivo · números/resultado · transição de módulo.

---

## 7. Ícones & ilustração

- Grade 24, traço 1.5, terminação arredondada, sem preenchimento.
- Corpo em quase-preto `#0E1420` + **um único** detalhe em coral `#EF5A3C`.
- Ilustração: composição geométrica (círculo, quadrado, pill, arco) ou objeto do trabalho (tela, pilha, relógio). Traço 2.5, máx. 4 formas, ~30% de espaço vazio.
- **Proibido:** pessoas, rostos, mascotes, robôs, cérebro de circuito, néon, gradiente, sombra, 3D/isométrico.

**Foto:** overlay gradiente `rgba(14,20,32,.1) → .8` de cima pra baixo. Luz natural, ambiente real. Coral só no texto sobre a foto, nunca como filtro.

---

## 8. Assinatura / monograma

Monograma "a" em **Instrument Serif itálico**, dentro de quadrado arredondado:
- Preto `#0E1420` com "a" coral `#EF5A3C` (principal)
- Coral `#EF5A3C` com "a" branca `#FFFFFF`
- Off-white `#FBFAF7` com "a" preta (dark mode)

Ver `assets/` para os SVGs prontos.

---

## 9. Voz

**Faça:**
- Assuma que a pessoa já usa IA — vá direto ao método.
- Nomeie a dor com as palavras dela ("salvo 140, aplico 5").
- Fale de ordem, sequência, "na ordem certa".
- Termine tudo com uma coisa pra aplicar hoje.
- Coral só onde há ação. Uma cor forte por peça.

**Evite:**
- "Aprenda IA do zero", "domine a IA", renda fácil.
- Tom de guru, promessa de transformação mágica.
- Verde da marca-mãe, rosa do Segundo Cérebro, lima.
- Sombra em botão, animação acima da dobra.
- Urgência falsa — vermelho escuro só com prazo real.

---

## 10. Kernel para IA

Cole este bloco antes de pedir qualquer peça desta submarca a um modelo de IA:

```
SUBMARCA: AMIA — Academia do Marketing com IA, curso + comunidade de Thaís Maia. PT-BR. Assinatura da Thaís discreta só no rodapé.
PROMESSA: você entra executando tarefas com IA e sai desenhando processos de marketing com IA. Não é escola de ferramenta nem "300 prompts mágicos" — é repertório, processo e aplicação.
TRANSFORMAÇÃO: de operadora de prompts a arquiteta de processos.
PROVA: sai com ATIVOS, não certificado — sistema rodando, playbook interno, horas devolvidas, portfólio de 3–5 fluxos, apresentação "IA em 90 dias", assistentes configurados.
COR: branco #FFFFFF (fundo) · off-white #FBFAF7 (faixa) · quase-preto #0E1420 (texto) · coral #EF5A3C (acento/CTA) · hover #D94A2E · vermelho #D0301A (só urgência real). Hierarquia por opacidade do #0E1420: 100/85/70/60/50.
TIPOGRAFIA: títulos Instrument Serif SEMPRE itálico; corpo DM Sans 400 (leading 1.75), UI 500/600; eyebrow uppercase 13px semibold tracking 0.14em coral.
LAYOUT: coluna 520–640px centralizada. Seções py 56–80px, hairline entre elas, faixas alternando branco/off-white.
COMPONENTES: CTA pill h52-56 coral sólido sem sombra. Card de preço raio 12px, ativo = borda coral 2px.
ÍCONES: grade 24, traço 1.5 round, sem preenchimento. Corpo #0E1420 + um detalhe #EF5A3C.
PROIBIDO: verde, rosa, lima, gradiente, sombra em botão, robô/mascote/cérebro de circuito, tom de guru, prazo inventado.
```

---

## Assets

- `assets/favicon-dark.svg` — monograma principal
- `assets/favicon-coral.svg` — variante coral
- `assets/favicon-light.svg` — variante clara (dark mode)
